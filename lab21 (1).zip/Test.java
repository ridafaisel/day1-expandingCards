import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Test {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		ArrayList<Student> stdnt = new ArrayList<Student>();
		stdnt.add(new Student("Redah alojayen", 201732518));
		stdnt.add(new Student("sultan alutaibi", 205939518));
		stdnt.add(new Student("ali alqaisum", 201732518));
		stdnt.add(new Student("saud alfaisel", 201732518));

		try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("output.dat"));) {

			
				output.writeObject(stdnt);
			
		}

		ArrayList<Student> stdnt2 = new ArrayList<Student>();

		try (ObjectInputStream input = new ObjectInputStream(new FileInputStream("output.dat"));) {

			
				stdnt2 = (ArrayList<Student>) (input.readObject());
		}

		for (int i = 0; i < stdnt2.size(); i++) {

			System.out.println(stdnt2.get(i));
		}

	}

}
